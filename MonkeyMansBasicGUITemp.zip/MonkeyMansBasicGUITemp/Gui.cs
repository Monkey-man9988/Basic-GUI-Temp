﻿using BepInEx;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.InputSystem;

namespace MonkeyMansBasicGUITemp
{
    [BepInEx.BepInPlugin("MonkeyMansBasicGUITemp", "Made By MonkeyMan love and thc <3", "1.0.0")]
    public class Gui : BepInEx.BaseUnityPlugin
    {
        /*
         
         README!!!
         IF YOU MAKE MODS FOR GORILLA TAG STEAM WHEN YOU BUILD THIS IT WILL BE AUTO PUT IN YOUR PLUGINS!!3

         */

        #region Vars
        //All of the varibles
        public Rect Window = new Rect(50, 50, 500, 475); // X Pos, Y Pos, Width, Height
        private bool GuiOpen = true; // Var For The GUI
        private float scale = 1f; // The Scale For The Ainmation
        private float animationSpeed = 10f; // The Ainmation Speed
        private Vector2 dragstart;// The Dragging Vector
        private bool dragging = false; // If It is dragging 
        #endregion
        public void Update() //Runs Ones Everyframe So If Your Game Is At 60FPS Then It WIll Run 60 Times A Second
        {
            if (UnityInput.Current.GetKeyDown(KeyCode.R)) // Key To Open And Close The GUI
            {
                GuiOpen = !GuiOpen;
            }

            float targetScale = GuiOpen ? 1f : 0f; // Checks if GuiOpen is true and if it is true then it puts the scale to 1 if its not true then it gose to 0
            scale = Mathf.MoveTowards(scale, targetScale, Time.deltaTime * animationSpeed); // The Scale Timer To Make The Ainmation Work
        }
        private void Dragging()// I Got Lazy So Credits To Malchi For The Dragging
        {
            if (Event.current.type == EventType.MouseDown && Window.Contains(Event.current.mousePosition))
            {
                dragging = true;
                dragstart = Event.current.mousePosition - new Vector2(Window.x, Window.y);
            }
            else
            {
                if (Event.current.type == EventType.MouseUp)
                {
                    dragging = false;
                }
            }
            if (dragging)
            {
                Window.position = Event.current.mousePosition - dragstart;
            }
        }
        public void OnGUI() // Unitys Base GUI System
        {
            if (scale > 0f)
            {
                float width = Window.width * scale;
                float height = Window.height * scale;
                float x = Window.x + (Window.width - width) / 2;
                float y = Window.y + (Window.height - height) / 2;

                Rect scaledRect = new Rect(x, y, width, height);
                GUI.Box(scaledRect, "Monkey Mans GUI Temp"); // Name Of The Gui

                float buttonWidth = 200f; // Button Width
                float buttonHeight = 75f; // Button Height
                float buttonX = scaledRect.x + (scaledRect.width - buttonWidth) / 2; // Buttons X Pos
                float buttonY = scaledRect.y + (scaledRect.height - buttonHeight) / 2; // Button Y Pos
                
                if (GUI.Button(new Rect(buttonX, buttonY, buttonWidth, buttonHeight), "Sub To MonkeyMan")) // Button Config And Naming 
                {
                    Application.OpenURL("https://www.youtube.com/@MMONKEYMAN9988/videos"); // Opens A URL to my YT channel!
                }
            }
            Dragging();
        }



    }
}
